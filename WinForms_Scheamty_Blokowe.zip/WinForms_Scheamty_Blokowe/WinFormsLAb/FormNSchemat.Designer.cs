﻿
namespace WinFormsLAb
{
    partial class FormNSchemat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormNSchemat));
            this.numericUpDownSzerkokosc = new System.Windows.Forms.NumericUpDown();
            this.numericUpdownWysokosc = new System.Windows.Forms.NumericUpDown();
            this.buttonOK = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.errorProviderSZerokosc = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderDlugosc = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSzerkokosc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpdownWysokosc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderSZerokosc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDlugosc)).BeginInit();
            this.SuspendLayout();
            // 
            // numericUpDownSzerkokosc
            // 
            resources.ApplyResources(this.numericUpDownSzerkokosc, "numericUpDownSzerkokosc");
            this.errorProviderDlugosc.SetError(this.numericUpDownSzerkokosc, resources.GetString("numericUpDownSzerkokosc.Error"));
            this.errorProviderSZerokosc.SetError(this.numericUpDownSzerkokosc, resources.GetString("numericUpDownSzerkokosc.Error1"));
            this.errorProviderDlugosc.SetIconAlignment(this.numericUpDownSzerkokosc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("numericUpDownSzerkokosc.IconAlignment"))));
            this.errorProviderSZerokosc.SetIconAlignment(this.numericUpDownSzerkokosc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("numericUpDownSzerkokosc.IconAlignment1"))));
            this.errorProviderSZerokosc.SetIconPadding(this.numericUpDownSzerkokosc, ((int)(resources.GetObject("numericUpDownSzerkokosc.IconPadding"))));
            this.errorProviderDlugosc.SetIconPadding(this.numericUpDownSzerkokosc, ((int)(resources.GetObject("numericUpDownSzerkokosc.IconPadding1"))));
            this.numericUpDownSzerkokosc.Maximum = new decimal(new int[] {
            4000,
            0,
            0,
            0});
            this.numericUpDownSzerkokosc.Name = "numericUpDownSzerkokosc";
            this.numericUpDownSzerkokosc.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            this.numericUpDownSzerkokosc.Validating += new System.ComponentModel.CancelEventHandler(this.numericUpDownSzerkokosc_Validating);
            // 
            // numericUpdownWysokosc
            // 
            resources.ApplyResources(this.numericUpdownWysokosc, "numericUpdownWysokosc");
            this.errorProviderDlugosc.SetError(this.numericUpdownWysokosc, resources.GetString("numericUpdownWysokosc.Error"));
            this.errorProviderSZerokosc.SetError(this.numericUpdownWysokosc, resources.GetString("numericUpdownWysokosc.Error1"));
            this.errorProviderDlugosc.SetIconAlignment(this.numericUpdownWysokosc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("numericUpdownWysokosc.IconAlignment"))));
            this.errorProviderSZerokosc.SetIconAlignment(this.numericUpdownWysokosc, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("numericUpdownWysokosc.IconAlignment1"))));
            this.errorProviderSZerokosc.SetIconPadding(this.numericUpdownWysokosc, ((int)(resources.GetObject("numericUpdownWysokosc.IconPadding"))));
            this.errorProviderDlugosc.SetIconPadding(this.numericUpdownWysokosc, ((int)(resources.GetObject("numericUpdownWysokosc.IconPadding1"))));
            this.numericUpdownWysokosc.Maximum = new decimal(new int[] {
            4000,
            0,
            0,
            0});
            this.numericUpdownWysokosc.Name = "numericUpdownWysokosc";
            this.numericUpdownWysokosc.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            this.numericUpdownWysokosc.Validating += new System.ComponentModel.CancelEventHandler(this.Wysokosc_Validating);
            // 
            // buttonOK
            // 
            resources.ApplyResources(this.buttonOK, "buttonOK");
            this.errorProviderSZerokosc.SetError(this.buttonOK, resources.GetString("buttonOK.Error"));
            this.errorProviderDlugosc.SetError(this.buttonOK, resources.GetString("buttonOK.Error1"));
            this.errorProviderSZerokosc.SetIconAlignment(this.buttonOK, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("buttonOK.IconAlignment"))));
            this.errorProviderDlugosc.SetIconAlignment(this.buttonOK, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("buttonOK.IconAlignment1"))));
            this.errorProviderSZerokosc.SetIconPadding(this.buttonOK, ((int)(resources.GetObject("buttonOK.IconPadding"))));
            this.errorProviderDlugosc.SetIconPadding(this.buttonOK, ((int)(resources.GetObject("buttonOK.IconPadding1"))));
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // textBox1
            // 
            resources.ApplyResources(this.textBox1, "textBox1");
            this.errorProviderDlugosc.SetError(this.textBox1, resources.GetString("textBox1.Error"));
            this.errorProviderSZerokosc.SetError(this.textBox1, resources.GetString("textBox1.Error1"));
            this.textBox1.ForeColor = System.Drawing.SystemColors.Window;
            this.errorProviderDlugosc.SetIconAlignment(this.textBox1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("textBox1.IconAlignment"))));
            this.errorProviderSZerokosc.SetIconAlignment(this.textBox1, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("textBox1.IconAlignment1"))));
            this.errorProviderSZerokosc.SetIconPadding(this.textBox1, ((int)(resources.GetObject("textBox1.IconPadding"))));
            this.errorProviderDlugosc.SetIconPadding(this.textBox1, ((int)(resources.GetObject("textBox1.IconPadding1"))));
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            // 
            // textBox2
            // 
            resources.ApplyResources(this.textBox2, "textBox2");
            this.errorProviderDlugosc.SetError(this.textBox2, resources.GetString("textBox2.Error"));
            this.errorProviderSZerokosc.SetError(this.textBox2, resources.GetString("textBox2.Error1"));
            this.errorProviderDlugosc.SetIconAlignment(this.textBox2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("textBox2.IconAlignment"))));
            this.errorProviderSZerokosc.SetIconAlignment(this.textBox2, ((System.Windows.Forms.ErrorIconAlignment)(resources.GetObject("textBox2.IconAlignment1"))));
            this.errorProviderSZerokosc.SetIconPadding(this.textBox2, ((int)(resources.GetObject("textBox2.IconPadding"))));
            this.errorProviderDlugosc.SetIconPadding(this.textBox2, ((int)(resources.GetObject("textBox2.IconPadding1"))));
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            // 
            // errorProviderSZerokosc
            // 
            this.errorProviderSZerokosc.ContainerControl = this;
            resources.ApplyResources(this.errorProviderSZerokosc, "errorProviderSZerokosc");
            // 
            // errorProviderDlugosc
            // 
            this.errorProviderDlugosc.ContainerControl = this;
            resources.ApplyResources(this.errorProviderDlugosc, "errorProviderDlugosc");
            // 
            // FormNSchemat
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.numericUpdownWysokosc);
            this.Controls.Add(this.numericUpDownSzerkokosc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FormNSchemat";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSzerkokosc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpdownWysokosc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderSZerokosc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDlugosc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numericUpDownSzerkokosc;
        private System.Windows.Forms.NumericUpDown numericUpdownWysokosc;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ErrorProvider errorProviderSZerokosc;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProviderDlugosc;
    }
}