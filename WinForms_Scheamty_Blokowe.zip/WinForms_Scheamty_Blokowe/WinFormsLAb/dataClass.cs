﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsLAb
{
    [Serializable]
    public class dataClass
    {
        public List<Blok> bloks;
        public int Pwight, Pheight;
        public dataClass()
        {
            bloks = new List<Blok>();
        }
    }
}
