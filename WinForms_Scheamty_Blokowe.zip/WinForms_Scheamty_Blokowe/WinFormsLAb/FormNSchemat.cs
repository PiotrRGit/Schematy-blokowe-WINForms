﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsLAb
{
    public partial class FormNSchemat : Form
    {
        public FormNSchemat()
        {
            InitializeComponent();
        }
        public FormNSchemat(Bitmap bit)
        {
            InitializeComponent();
        }

        private void numericUpDownSzerkokosc_Validating(object sender, CancelEventArgs e)
        {
            if (numericUpDownSzerkokosc.Value < 400)
            {
                errorProviderSZerokosc.SetError(numericUpDownSzerkokosc, "musi wynosic co najmniej 400");
                e.Cancel = true;
                return;
            }
            errorProviderSZerokosc.SetError(numericUpDownSzerkokosc, String.Empty);
            e.Cancel = false;
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            {
                //drawArea.Dispose();
                Form1 parent = (Form1)this.Owner;
                parent.NewSchemat(Convert.ToInt32(numericUpDownSzerkokosc.Value), Convert.ToInt32(numericUpdownWysokosc.Value),true);
                this.Close();
            }
        }

        private void Wysokosc_Validating(object sender, CancelEventArgs e)
        {
            if (numericUpdownWysokosc.Value < 400)
            {
                errorProviderDlugosc.SetError(numericUpdownWysokosc, "musi wynosic co najmniej 400");
                e.Cancel = true;
                return;
            }
            errorProviderDlugosc.SetError(numericUpdownWysokosc, String.Empty);
            e.Cancel = false;
        }
    }
}
