﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsLAb
{
    [Serializable]
    abstract public class Node
    {
        public float x, y;
        public Node(float X, float Y) 
        {
            x = X;
            y = Y;
        }

        public void UpdateNode(float X, float Y)
        {
            x = X;
            y = Y;
        }

        public bool isclicked(float X,float Y)
        {
            bool temp = ((x - X) * (x - X) + (y - Y) * (y - Y) < 30);
            return ((x - X) * (x - X) + (y - Y) * (y - Y) < 30);
        }
        public abstract void DrawNode(Bitmap map);

    }
    [Serializable]
    public class Nodestart : Node
    {
        public Nodeend end;
        public Nodestart(float X, float Y) : base(X, Y)
        {

            end = null;
        }
        override public void DrawNode(Bitmap drawArea)
        {
            using (Graphics g = Graphics.FromImage(drawArea))
            {
                if (end != null)
                {
                    using (Pen p = new Pen(Brushes.Black, 2f))
                    {
                        using (System.Drawing.Drawing2D.AdjustableArrowCap bigArrow = new System.Drawing.Drawing2D.AdjustableArrowCap(5, 5))
                        {
                            //Specify the EndCap, because we're drawing a right-facing arrow
                            //p.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
                            p.CustomEndCap = bigArrow;
                            //Draw the arrow
                            g.DrawLine(p, x, y, end.x, end.y);
                        }
                    }
                }
                else
                {
                    g.FillEllipse(Brushes.Black, x - 5, y - 5, 10, 10);
                }
            }

        }
    }
    [Serializable]
    public class Nodeend : Node
    {
        public Nodestart start;
        public Nodeend(float X, float Y) : base(X, Y)
        {
            start = null;
        }

        override public void DrawNode(Bitmap drawArea)
        {
            using (Graphics g = Graphics.FromImage(drawArea))
            {
                if (start == null)
                {
                    g.FillEllipse(Brushes.Black, x - 5, y - 5, 10, 10);
                    g.FillEllipse(Brushes.White, x - 3, y - 3, 6, 6);
                }
            }

        }
    }
}
