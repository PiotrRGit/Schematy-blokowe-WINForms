﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;

namespace WinFormsLAb
{

    public partial class Form1 : Form
    {
        Bitmap drawArea;
        //private int dane.Pwight , dane.Pheight;
        //private BlokDecyzyjny blokDecyzyjny;
        //private BlokOperacyjny blokOperacyjny;
        //private List<Blok> dane.bloks;
        private dataClass dane;
        private Blok highlighted;
        private bool middlepressed;
        private (float,float) moveofset;
        private bool isstart;
        private Nodestart startoflink;
        public Form1()
        {
            InitializeComponent();
            drawArea = new Bitmap(pictureBoxMain.Size.Width, pictureBoxMain.Size.Height);
            dane = new dataClass();
            pictureBoxMain.Image = drawArea;
            dane.Pwight  = 600;
            dane.Pheight = 600;
            NewSchemat(dane.Pwight, dane.Pheight, false);
            middlepressed = false;
            highlighted = null;
            DrawAll();
            isstart = false;
            startoflink = null;
            radioButtonPol_CheckedChanged(null, null);
        }

        public void DrawAll()
        {
            //drawArea = new Bitmap(dane.Pwight , dane.Pheight);
            //pictureBoxMain.Image = drawArea;
            using (Graphics g = Graphics.FromImage(drawArea))
            {
                g.Clear(Color.LightBlue);
            }
            foreach (var b in dane.bloks)
            {
                b.draw(drawArea);
            }
            pictureBoxMain.Refresh();
        }

        public void NewSchemat(int x, int y,bool clear)
        {
            if (highlighted!=null)
            {
                highlighted.highlight = false;
                highlighted = null;
            }
            textBoxtextEdit.Text = "";
            textBoxtextEdit.Enabled = false;
            dane.Pwight  = x;
            dane.Pheight = y;
            if (clear)
            {
                dane.bloks.Clear();
            }
            drawArea.Dispose();
            drawArea = new Bitmap(dane.Pwight , dane.Pheight);
            pictureBoxMain.Image = drawArea;
            System.Drawing.Size f = new System.Drawing.Size(dane.Pwight , dane.Pheight);
            panelPicture.AutoScrollMinSize = (f);
            DrawAll();
            isstart = false;
        }

        private void Lmousepressed(object sender, MouseEventArgs e)
        {
            if (radioButtonBlokOperacyjny.Checked == true)
            {
                //blokOperacyjny = new BlokOperacyjny(drawArea, e, Font);
                dane.bloks.Add(new BlokOperacyjny(drawArea, e, Font));
                DrawAll();
            }
            if (radioButtonThrash.Checked == true)
            {
                Blok tmp=null;
                double tempodl=double.MaxValue;
                foreach (Blok b in dane.bloks)
                {
                    if (b.isclicked(e.X, e.Y) &&tempodl>b.odleglosc(e.X, e.Y))
                    {
                        tmp = b;
                        tempodl = b.odleglosc(e.X, e.Y);
                        break;
                    }

                }
                if (tmp!=null)
                {

                    foreach(Node n in tmp.nodes)
                    {
                        if (n != null && n is Nodestart)
                        {
                            Nodestart tmpnode = (Nodestart)n;
                            if(tmpnode.end!=null)
                                tmpnode.end.start = null;
                        }
                        if (n != null&&n is Nodeend)
                        {
                            Nodeend tmpnode = (Nodeend)n;
                            if (tmpnode.start != null)
                                tmpnode.start.end = null;
                        }
                    }

                    if(tmp is BlokStart)
                    {
                        isstart = false;
                    }
                    if(tmp == highlighted)
                    {
                        highlighted.highlight = false;
                        highlighted = null;
                        textBoxtextEdit.Text = "";
                        textBoxtextEdit.Enabled = false;
                    }
                    dane.bloks.Remove(tmp);
                }
                DrawAll();
            }

            if (radioButtonLink.Checked == true)
            { 
                foreach(Blok b in dane.bloks)
                {
                    foreach(Node n in b.nodes)
                    {
                        if(n!=null&&n is Nodestart && n.isclicked(e.X, e.Y))
                        {
                            Nodestart tmp = (Nodestart)n;
                            if (tmp.end == null)
                            {
                                startoflink = (Nodestart)n;
                                break;
                            }
                        }
                    }
                }
            }

            if (radioButtonBlokDecyzyjny.Checked == true)
            {
                dane.bloks.Add(new BlokDecyzyjny(drawArea, e, Font));
                DrawAll();
            }
            if (radioButtonStart.Checked == true)
            {
                if (isstart == false)
                {
                    dane.bloks.Add(new BlokStart(drawArea, e, Font));
                    isstart = true;
                }
                else
                {
                    var formPopup = new FormExtraStart();
                    formPopup.StartPosition = FormStartPosition.CenterParent;
                    formPopup.ShowDialog(this);
                }
                DrawAll();
            }

            if (radioButtonEnd.Checked == true)
            {
                dane.bloks.Add(new BlokStop(drawArea, e, Font));
                DrawAll();
            }
        }

        private void Rmousepressed(object sender, MouseEventArgs e)
        {
            double temp = double.MaxValue;
            if (highlighted != null)
            {
                highlighted.highlight = false;
                highlighted = null;
            }
            foreach (Blok b in dane.bloks)
            {
                if (b.isclicked(e.X, e.Y) && temp > b.odleglosc(e.X, e.Y))
                {
                    temp = b.odleglosc(e.X, e.Y);
                    highlighted = b;
                }
                else
                {
                    b.highlight = false;
                }
            }
            if (highlighted != null)
            {
                highlighted.highlight = true;
                textBoxtextEdit.Text = highlighted.text;
                if (highlighted is BlokOperacyjny || highlighted is BlokDecyzyjny)
                {
                    textBoxtextEdit.Enabled = true;
                }
                else
                {
                    textBoxtextEdit.Enabled = false;
                }
            }
            else
            {
                textBoxtextEdit.Text = "";
                textBoxtextEdit.Enabled = false;
            }
            DrawAll();
        }
        private void pictureBoxMain_MouseDown_1(object sender, MouseEventArgs e)
        {
            if (!middlepressed)
            {
                if (e.Button == MouseButtons.Left)
                {
                    Lmousepressed(sender, e);
                }
                if (e.Button == MouseButtons.Right)
                {
                    Rmousepressed(sender, e);
                }
                if (e.Button == MouseButtons.Middle)
                {
                    if (highlighted != null)
                    {
                        middlepressed = true;
                        moveofset = (highlighted.blokX - e.X, highlighted.blokY - e.Y);
                    }
                }
            }
        }

        private void pictureBoxMain_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Middle && middlepressed == true)
            {
                if (highlighted.blokX < 0)
                {
                    highlighted.blokX = 0;
                }
                if (highlighted.blokY < 0)
                {
                    highlighted.blokY = 0;
                }
                if (highlighted.blokX > dane.Pwight )
                {
                    highlighted.blokX = dane.Pwight ;
                }
                if (highlighted.blokY > dane.Pheight)
                {
                    highlighted.blokY = dane.Pheight;
                }
                DrawAll();
                middlepressed = false;
            }
            if (e.Button == MouseButtons.Left && startoflink != null)
            {
                foreach (Blok b in dane.bloks)
                {
                    foreach (Node n in b.nodes)
                    {
                        if (n != null && n is Nodeend && n.isclicked(e.X, e.Y))
                        {

                            Nodeend tmp = (Nodeend)n;
                            if (tmp.start == null) {
                                tmp.start = startoflink;
                                startoflink.end = tmp;
                                startoflink = null;
                                break;
                            }
                        }
                    }
                    if (startoflink == null) break;
                }
                startoflink = null;
                DrawAll();
            }
        }

        private void pictureBoxMain_MouseMove(object sender, MouseEventArgs e)
        {
            if(middlepressed == true && highlighted != null)
            {
                highlighted.blokX = e.X + moveofset.Item1;
                highlighted.blokY = e.Y + moveofset.Item2;
                DrawAll();
            }
            if (startoflink != null)
            {
                DrawAll();
                using (Graphics g = Graphics.FromImage(drawArea))
                {
                    using (Pen p = new Pen(Brushes.Black, 2f))
                    {
                        //Specify the EndCap, because we're drawing a right-facing arrow
                        p.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;

                        //Draw the arrow
                        g.DrawLine(p, e.X, e.Y, startoflink.x, startoflink.y);

                    }
                }
                pictureBoxMain.Refresh();
            }
        }

        private void textBoxtextEdit_TextChanged(object sender, EventArgs e)
        {
            if (highlighted != null){
                highlighted.text = textBoxtextEdit.Text;
                DrawAll();
            }
        }


        private void buttonNowyScheamt_Click(object sender, EventArgs e)
        {
            var formPopup = new FormNSchemat(drawArea);
            if (highlighted != null)
            {
                highlighted = null;
            }
            formPopup.StartPosition = FormStartPosition.CenterParent;
            formPopup.ShowDialog(this);
        }


        //https://stackoverflow.com/questions/7556367/how-do-i-change-the-culture-of-a-winforms-application-at-runtime?fbclid=IwAR3ZUhN_m-0OKdHHrNA9JptbfnxoV7maY1aLt-e9jt3z-FViT2OI09kmmFA
        private void radioButtonAng_CheckedChanged(object sender, EventArgs e)
        {
            System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en-BG");
            ComponentResourceManager resources = new ComponentResourceManager(typeof(Form1));
            resources.ApplyResources(this, "$this");
            applyResources(resources, this.Controls);
        }

        private void radioButtonPol_CheckedChanged(object sender, EventArgs e)
        {
            System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("pl-PL");
            ComponentResourceManager resources = new ComponentResourceManager(typeof(Form1));
            resources.ApplyResources(this, "$this");
            applyResources(resources, this.Controls);
        }
        //https://docs.microsoft.com/pl-pl/dotnet/api/microsoft.win32.savefiledialog?view=windowsdesktop-6.0&fbclid=IwAR21sZT4inztii3GHgkkznE3xJrHzEwig3ntkjN3yrRFUlCl0LMScXYuTnI
        private void buttonZapiszSchemat_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            //dlg.FileName = "Document"; // Default file name
            dlg.DefaultExt = ".diag"; // Default file extension
            dlg.Filter = "Text documents (.diag)|*.diag"; // Filter files by extension

            // Show save file dialog box
            //Nullable<bool> result = dlg.ShowDialog();

            // Process save file dialog box results
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                // Save document
                string filename = dlg.FileName;
                FileStream fs = new FileStream(filename, FileMode.Create);
                BinaryFormatter binform = new BinaryFormatter();
                binform.Serialize(fs, dane);
                fs.Close();
            }
        }

        private void buttonWczytajScheamt_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            //dlg.FileName = "Document"; // Default file name
            dlg.DefaultExt = ".diag"; // Default file extension
            dlg.Filter = "Text documents (.diag)|*.diag"; // Filter files by extension

            // Show save file dialog box
            //Nullable<bool> result = dlg.ShowDialog();

            // Process save file dialog box results
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                // Save document
                string filename = dlg.FileName;
                FileStream fs = new FileStream(filename, FileMode.Open);
                BinaryFormatter binform = new BinaryFormatter();
                dane = (dataClass)binform.Deserialize(fs);
                fs.Close();
                NewSchemat(dane.Pwight, dane.Pheight, false);

                DrawAll();
                foreach(Blok b in dane.bloks)
                {
                    if (b.ishighlighted())
                    {
                        highlighted = b;
                        textBoxtextEdit.Text = b.text;
                        textBoxtextEdit.Enabled = true;
                    }
                }
            }
        }

        private void applyResources(ComponentResourceManager resources, Control.ControlCollection ctls)
        {
            foreach (Control ctl in ctls)
            {
                resources.ApplyResources(ctl, ctl.Name);
                applyResources(resources, ctl.Controls);
            }
        }
    }
}
