﻿
namespace WinFormsLAb
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        
        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxtextEdit = new System.Windows.Forms.TextBox();
            this.groupBoxEdycja = new System.Windows.Forms.GroupBox();
            this.radioButtonThrash = new System.Windows.Forms.RadioButton();
            this.label = new System.Windows.Forms.Label();
            this.radioButtonLink = new System.Windows.Forms.RadioButton();
            this.radioButtonEnd = new System.Windows.Forms.RadioButton();
            this.radioButtonStart = new System.Windows.Forms.RadioButton();
            this.radioButtonBlokDecyzyjny = new System.Windows.Forms.RadioButton();
            this.radioButtonBlokOperacyjny = new System.Windows.Forms.RadioButton();
            this.groupBoxPlik = new System.Windows.Forms.GroupBox();
            this.buttonWczytajScheamt = new System.Windows.Forms.Button();
            this.buttonZapiszSchemat = new System.Windows.Forms.Button();
            this.buttonNowyScheamt = new System.Windows.Forms.Button();
            this.groupBoxJezyk = new System.Windows.Forms.GroupBox();
            this.radioButtonPol = new System.Windows.Forms.RadioButton();
            this.radioButtonAng = new System.Windows.Forms.RadioButton();
            this.panelPicture = new System.Windows.Forms.Panel();
            this.pictureBoxMain = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBoxEdycja.SuspendLayout();
            this.groupBoxPlik.SuspendLayout();
            this.groupBoxJezyk.SuspendLayout();
            this.panelPicture.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMain)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            resources.ApplyResources(this.tableLayoutPanel1, "tableLayoutPanel1");
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panelPicture, 0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            // 
            // tableLayoutPanel2
            // 
            resources.ApplyResources(this.tableLayoutPanel2, "tableLayoutPanel2");
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.groupBoxPlik, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBoxJezyk, 0, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            // 
            // tableLayoutPanel3
            // 
            resources.ApplyResources(this.tableLayoutPanel3, "tableLayoutPanel3");
            this.tableLayoutPanel3.Controls.Add(this.textBoxtextEdit, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.groupBoxEdycja, 0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            // 
            // textBoxtextEdit
            // 
            resources.ApplyResources(this.textBoxtextEdit, "textBoxtextEdit");
            this.textBoxtextEdit.Name = "textBoxtextEdit";
            this.textBoxtextEdit.TextChanged += new System.EventHandler(this.textBoxtextEdit_TextChanged);
            // 
            // groupBoxEdycja
            // 
            this.groupBoxEdycja.Controls.Add(this.radioButtonThrash);
            this.groupBoxEdycja.Controls.Add(this.label);
            this.groupBoxEdycja.Controls.Add(this.radioButtonLink);
            this.groupBoxEdycja.Controls.Add(this.radioButtonEnd);
            this.groupBoxEdycja.Controls.Add(this.radioButtonStart);
            this.groupBoxEdycja.Controls.Add(this.radioButtonBlokDecyzyjny);
            this.groupBoxEdycja.Controls.Add(this.radioButtonBlokOperacyjny);
            resources.ApplyResources(this.groupBoxEdycja, "groupBoxEdycja");
            this.groupBoxEdycja.Name = "groupBoxEdycja";
            this.groupBoxEdycja.TabStop = false;
            // 
            // radioButtonThrash
            // 
            resources.ApplyResources(this.radioButtonThrash, "radioButtonThrash");
            this.radioButtonThrash.Name = "radioButtonThrash";
            this.radioButtonThrash.TabStop = true;
            this.radioButtonThrash.UseVisualStyleBackColor = true;
            // 
            // label
            // 
            resources.ApplyResources(this.label, "label");
            this.label.Name = "label";
            // 
            // radioButtonLink
            // 
            resources.ApplyResources(this.radioButtonLink, "radioButtonLink");
            this.radioButtonLink.Name = "radioButtonLink";
            this.radioButtonLink.TabStop = true;
            this.radioButtonLink.UseVisualStyleBackColor = true;
            // 
            // radioButtonEnd
            // 
            resources.ApplyResources(this.radioButtonEnd, "radioButtonEnd");
            this.radioButtonEnd.Name = "radioButtonEnd";
            this.radioButtonEnd.TabStop = true;
            this.radioButtonEnd.UseVisualStyleBackColor = true;
            // 
            // radioButtonStart
            // 
            resources.ApplyResources(this.radioButtonStart, "radioButtonStart");
            this.radioButtonStart.Name = "radioButtonStart";
            this.radioButtonStart.TabStop = true;
            this.radioButtonStart.UseVisualStyleBackColor = true;
            // 
            // radioButtonBlokDecyzyjny
            // 
            resources.ApplyResources(this.radioButtonBlokDecyzyjny, "radioButtonBlokDecyzyjny");
            this.radioButtonBlokDecyzyjny.Name = "radioButtonBlokDecyzyjny";
            this.radioButtonBlokDecyzyjny.TabStop = true;
            this.radioButtonBlokDecyzyjny.UseVisualStyleBackColor = true;
            // 
            // radioButtonBlokOperacyjny
            // 
            resources.ApplyResources(this.radioButtonBlokOperacyjny, "radioButtonBlokOperacyjny");
            this.radioButtonBlokOperacyjny.Name = "radioButtonBlokOperacyjny";
            this.radioButtonBlokOperacyjny.TabStop = true;
            this.radioButtonBlokOperacyjny.UseVisualStyleBackColor = true;
            // 
            // groupBoxPlik
            // 
            resources.ApplyResources(this.groupBoxPlik, "groupBoxPlik");
            this.groupBoxPlik.Controls.Add(this.buttonWczytajScheamt);
            this.groupBoxPlik.Controls.Add(this.buttonZapiszSchemat);
            this.groupBoxPlik.Controls.Add(this.buttonNowyScheamt);
            this.groupBoxPlik.Name = "groupBoxPlik";
            this.groupBoxPlik.TabStop = false;
            // 
            // buttonWczytajScheamt
            // 
            resources.ApplyResources(this.buttonWczytajScheamt, "buttonWczytajScheamt");
            this.buttonWczytajScheamt.Name = "buttonWczytajScheamt";
            this.buttonWczytajScheamt.UseVisualStyleBackColor = true;
            this.buttonWczytajScheamt.Click += new System.EventHandler(this.buttonWczytajScheamt_Click);
            // 
            // buttonZapiszSchemat
            // 
            resources.ApplyResources(this.buttonZapiszSchemat, "buttonZapiszSchemat");
            this.buttonZapiszSchemat.Name = "buttonZapiszSchemat";
            this.buttonZapiszSchemat.UseVisualStyleBackColor = true;
            this.buttonZapiszSchemat.Click += new System.EventHandler(this.buttonZapiszSchemat_Click);
            // 
            // buttonNowyScheamt
            // 
            resources.ApplyResources(this.buttonNowyScheamt, "buttonNowyScheamt");
            this.buttonNowyScheamt.Name = "buttonNowyScheamt";
            this.buttonNowyScheamt.UseVisualStyleBackColor = true;
            this.buttonNowyScheamt.Click += new System.EventHandler(this.buttonNowyScheamt_Click);
            // 
            // groupBoxJezyk
            // 
            this.groupBoxJezyk.Controls.Add(this.radioButtonPol);
            this.groupBoxJezyk.Controls.Add(this.radioButtonAng);
            resources.ApplyResources(this.groupBoxJezyk, "groupBoxJezyk");
            this.groupBoxJezyk.Name = "groupBoxJezyk";
            this.groupBoxJezyk.TabStop = false;
            // 
            // radioButtonPol
            // 
            resources.ApplyResources(this.radioButtonPol, "radioButtonPol");
            this.radioButtonPol.Name = "radioButtonPol";
            this.radioButtonPol.TabStop = true;
            this.radioButtonPol.UseVisualStyleBackColor = true;
            this.radioButtonPol.CheckedChanged += new System.EventHandler(this.radioButtonPol_CheckedChanged);
            // 
            // radioButtonAng
            // 
            resources.ApplyResources(this.radioButtonAng, "radioButtonAng");
            this.radioButtonAng.Name = "radioButtonAng";
            this.radioButtonAng.TabStop = true;
            this.radioButtonAng.UseVisualStyleBackColor = true;
            this.radioButtonAng.CheckedChanged += new System.EventHandler(this.radioButtonAng_CheckedChanged);
            // 
            // panelPicture
            // 
            resources.ApplyResources(this.panelPicture, "panelPicture");
            this.panelPicture.Controls.Add(this.pictureBoxMain);
            this.panelPicture.Name = "panelPicture";
            // 
            // pictureBoxMain
            // 
            resources.ApplyResources(this.pictureBoxMain, "pictureBoxMain");
            this.pictureBoxMain.Name = "pictureBoxMain";
            this.pictureBoxMain.TabStop = false;
            this.pictureBoxMain.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBoxMain_MouseDown_1);
            this.pictureBoxMain.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBoxMain_MouseMove);
            this.pictureBoxMain.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBoxMain_MouseUp);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBoxEdycja.ResumeLayout(false);
            this.groupBoxEdycja.PerformLayout();
            this.groupBoxPlik.ResumeLayout(false);
            this.groupBoxJezyk.ResumeLayout(false);
            this.panelPicture.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMain)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBoxPlik;
        private System.Windows.Forms.GroupBox groupBoxEdycja;
        private System.Windows.Forms.GroupBox groupBoxJezyk;
        private System.Windows.Forms.Button buttonWczytajScheamt;
        private System.Windows.Forms.Button buttonZapiszSchemat;
        private System.Windows.Forms.Button buttonNowyScheamt;
        private System.Windows.Forms.RadioButton radioButtonBlokDecyzyjny;
        private System.Windows.Forms.RadioButton radioButtonBlokOperacyjny;
        private System.Windows.Forms.RadioButton radioButtonPol;
        private System.Windows.Forms.RadioButton radioButtonAng;
        private System.Windows.Forms.Panel panelPicture;
        private System.Windows.Forms.PictureBox pictureBoxMain;
        private System.Windows.Forms.TextBox textBoxtextEdit;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.RadioButton radioButtonThrash;
        private System.Windows.Forms.RadioButton radioButtonLink;
        private System.Windows.Forms.RadioButton radioButtonEnd;
        private System.Windows.Forms.RadioButton radioButtonStart;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
    }
}

