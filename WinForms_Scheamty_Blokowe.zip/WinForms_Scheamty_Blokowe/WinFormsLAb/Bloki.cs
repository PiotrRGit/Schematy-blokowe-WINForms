﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsLAb
{
    [Serializable]
    abstract public class Blok
    {
        public float blokX, blokY;
        public bool highlight;
        public string text;
        public Node[] nodes;
        public Blok(Bitmap drawAreai, MouseEventArgs ei, Font fi)
        {
            nodes = new Node[3];
            nodes[0] = null;
            nodes[1] = null;
            nodes[2] = null;
            blokX = ei.X;
            blokY = ei.Y;
            highlight = false;
        }
        public virtual void draw(Bitmap drawArea) { }

        public bool ishighlighted()
        {
            return highlight;
        }
        public double odleglosc(int x, int y) 
        {
            return Math.Sqrt((blokX - x) * (blokX - x) + (blokY - y) * (blokY - y));
        }
        public abstract bool isclicked(int x, int y);
    }
    [Serializable]
    public class BlokDecyzyjny : Blok
    {
        public BlokDecyzyjny(Bitmap drawAreai, MouseEventArgs ei, Font fi) : base(drawAreai, ei, fi)
        {
            //System.Globalization.Get
            //Form1

            //text = "Blok Decyzyjny";
            text = Properties.Resources.BlokDecyzyjny;

            nodes[0] = new Nodestart(blokX - 60, blokY);
            nodes[1] = new Nodestart(blokX + 60, blokY);
            nodes[2] = new Nodeend(blokX, blokY-20);
        }
        override public void draw(Bitmap drawArea)
        {
            using (Graphics g = Graphics.FromImage(drawArea))
            {
                PointF point1 = new PointF(blokX - 60, blokY);
                PointF point2 = new PointF(blokX, blokY - 20);
                PointF point3 = new PointF(blokX + 60, blokY);
                PointF point4 = new PointF(blokX, blokY + 20);
                PointF[] curvePoints = { point1, point2, point3, point4 };
                if (highlight == true)
                {
                    using (Pen Penn = new Pen(Brushes.Black, 2))
                    {
                        Penn.DashPattern = new float[] { 2, 1 };
                        g.DrawPolygon(Penn, curvePoints);
                    }
                }
                else
                {
                    using (Pen Penn = new Pen(Brushes.Black, 2))
                    {
                        g.DrawPolygon(Penn, curvePoints);
                    }

                }
                g.FillPolygon(Brushes.White, curvePoints);
                //g.DrawString(text, f, Brushes.Black, blokX - 40, blokY - 7, StringFormat.GenericDefault);

                using (StringFormat stringFormat = new StringFormat())
                {
                    RectangleF rectF1 = new RectangleF(blokX-55, blokY-18, 110, 36);
                    stringFormat.Alignment = StringAlignment.Center;
                    stringFormat.LineAlignment = StringAlignment.Center;
                    using (Font myFont = new Font("Arial", 8))
                    {
                        g.DrawString(text, myFont, Brushes.Black, rectF1, stringFormat);
                    }
                }


            }
            nodes[0].UpdateNode(blokX-60, blokY);
            nodes[1].UpdateNode(blokX+60, blokY);
            nodes[2].UpdateNode(blokX, blokY - 20);
            nodes[0].DrawNode(drawArea);
            nodes[1].DrawNode(drawArea);
            nodes[2].DrawNode(drawArea);

        }
        override public bool isclicked(int x, int y)
        {
            if (Math.Abs(x - blokX) <= 60 && Math.Abs(y - blokY)< Math.Abs(20-2/6* Math.Abs(x - blokX)))
            {
                return true;
            }
            return false;
        }
    }
    [Serializable]
    public class BlokOperacyjny : Blok
    {
        public BlokOperacyjny(Bitmap drawAreai, MouseEventArgs ei, Font fi) : base(drawAreai, ei, fi)
        {
            text = Properties.Resources.BlokOperacyjny;
            nodes[0] = new Nodestart(blokX, blokY+25);
            nodes[1] = new Nodeend(blokX, blokY-25);
        }
        override public void draw(Bitmap drawArea)
        {
            using (Graphics g = Graphics.FromImage(drawArea))
            {
                g.FillRectangle(Brushes.White, blokX - 60, blokY - 25, 120, 50);
                if (highlight == true)
                {
                    using (Pen Penn = new Pen(Brushes.Black, 2))
                    {
                        Penn.DashPattern = new float[] { 2, 1 };
                        g.DrawRectangle(Penn, blokX - 60, blokY - 25, 120, 50);
                    }
                }
                else
                {
                    using (Pen Penn = new Pen(Brushes.Black, 2))
                    {
                        g.DrawRectangle(Penn, blokX - 60, blokY - 25, 120, 50);
                    }
                }

                //g.DrawString(text, f, Brushes.Black, blokX - 45, blokY - 10, StringFormat.GenericDefault);
                using (StringFormat stringFormat = new StringFormat())
                {
                    RectangleF rectF1 = new RectangleF(blokX - 55, blokY - 18, 110, 36);
                    stringFormat.Alignment = StringAlignment.Center;
                    stringFormat.LineAlignment = StringAlignment.Center;
                    using (Font myFont = new Font("Arial", 8))
                    {
                        g.DrawString(text, myFont, Brushes.Black, rectF1, stringFormat);
                    }
                }

            }

            nodes[0].UpdateNode(blokX, blokY + 25);
            nodes[1].UpdateNode(blokX, blokY - 25);
            nodes[0].DrawNode(drawArea);
            nodes[1].DrawNode(drawArea);
        }
        override public bool isclicked(int x, int y)
        {
            if (Math.Abs(x - blokX) <= 60 && Math.Abs(y - blokY) <= 20)
            {
                return true;
            }
            return false;
        }

    }
    [Serializable]
    public class BlokStart : Blok
    {
        public BlokStart(Bitmap drawAreai, MouseEventArgs ei, Font fi) : base(drawAreai, ei, fi)
        {
            text = "START";
            nodes[0] = new Nodestart(blokX, blokY + 25);
        }
        override public void draw(Bitmap drawArea)
        {
            using (Graphics g = Graphics.FromImage(drawArea))
            {
                g.FillEllipse(Brushes.White, blokX - 40, blokY - 25, 80, 50);
                if (highlight == true)
                {
                    using (Pen Penn = new Pen(Brushes.DarkGreen, 2))
                    {
                        Penn.DashPattern = new float[] { 2, 1 };
                        g.DrawEllipse(Penn, blokX - 40, blokY - 25, 80, 50);
                    }
                }
                else
                {
                    using (Pen Penn = new Pen(Brushes.DarkGreen, 2))
                    {
                        g.DrawEllipse(Penn, blokX - 40, blokY - 25, 80, 50);
                    }
                }

                using (StringFormat stringFormat = new StringFormat())
                {
                    RectangleF rectF1 = new RectangleF(blokX - 55, blokY - 18, 110, 36);
                    stringFormat.Alignment = StringAlignment.Center;
                    stringFormat.LineAlignment = StringAlignment.Center;
                    using (Font myFont = new Font("Arial", 8))
                    {
                        g.DrawString(text, myFont, Brushes.Black, rectF1, stringFormat);
                    }
                }
            }
            nodes[0].UpdateNode(blokX, blokY + 25);
            nodes[0].DrawNode(drawArea);
        }
        override public bool isclicked(int x, int y)
        {
            if (((x - blokX) * (x - blokX) / 40 / 40) + ((y - blokY) * (y - blokY) / 25 / 25) < 1)
            {
                return true;
            }
            return false;
        }

    }
    [Serializable]
    public class BlokStop : Blok
    {
        public BlokStop(Bitmap drawAreai, MouseEventArgs ei, Font fi) : base(drawAreai, ei, fi)
        {
            text = "STOP";
            nodes[0] = new Nodeend(blokX, blokY - 25);
        }
        override public void draw(Bitmap drawArea)
        {
            using (Graphics g = Graphics.FromImage(drawArea))
            {
                g.FillEllipse(Brushes.White, blokX - 40, blokY - 25, 80, 50);
                if (highlight == true)
                {
                    using (Pen Penn = new Pen(Brushes.Red, 2))
                    {
                        Penn.DashPattern = new float[] { 2, 1 };
                        g.DrawEllipse(Penn, blokX - 40, blokY - 25, 80, 50);
                    }
                }
                else
                {
                    using (Pen Penn = new Pen(Brushes.Red, 2))
                    {
                        g.DrawEllipse(Penn, blokX - 40, blokY - 25, 80, 50);
                    }
                }

                //g.DrawString(text, f, Brushes.Black, blokX - 20, blokY - 10, StringFormat.GenericDefault);
                using (StringFormat stringFormat = new StringFormat())
                {
                    RectangleF rectF1 = new RectangleF(blokX - 55, blokY - 18, 110, 36);
                    stringFormat.Alignment = StringAlignment.Center;
                    stringFormat.LineAlignment = StringAlignment.Center;
                    using (Font myFont = new Font("Arial", 8))
                    {
                        g.DrawString(text, myFont, Brushes.Black, rectF1, stringFormat);
                    }
                }
            }
            nodes[0].UpdateNode(blokX, blokY - 25);
            nodes[0].DrawNode(drawArea);
        }
        override public bool isclicked(int x, int y)
        {
            if (((x - blokX) * (x - blokX) / 40 / 40) + ((y - blokY) * (y - blokY) / 25 / 25) < 1)
            {
                return true;
            }
            return false;
        }

    }
}
